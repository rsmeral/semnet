/**
 * Scraper, a processor used in co-operation with crawler. Turns entity documents into statements.
 */
package xsmeral.semnet.scraper;
