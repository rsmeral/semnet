/**
 * Classes for management of processing jobs
 */
package xsmeral.semnet.manager;
