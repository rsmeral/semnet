/**
 * The query interface.
 */
package xsmeral.semnet.query;
