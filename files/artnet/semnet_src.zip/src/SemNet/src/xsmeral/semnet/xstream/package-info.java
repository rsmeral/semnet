/**
 * Converters used by XStream for XML (de)serialization
 */
package xsmeral.semnet.xstream;
