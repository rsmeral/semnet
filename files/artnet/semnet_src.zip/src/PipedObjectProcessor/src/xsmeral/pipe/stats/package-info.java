/**
 * Provides classes for tracking statistics of processors.
 */
package xsmeral.pipe.stats;
