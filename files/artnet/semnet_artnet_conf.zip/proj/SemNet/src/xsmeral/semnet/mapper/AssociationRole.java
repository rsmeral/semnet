package xsmeral.semnet.mapper;

public enum AssociationRole {

    SUBJECT, PREDICATE, OBJECT
}
