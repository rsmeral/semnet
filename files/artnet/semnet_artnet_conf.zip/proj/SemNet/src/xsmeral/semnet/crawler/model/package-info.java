/**
 * Data containers used by the crawler - host and entity descriptors, entity document, URL entry
 */
package xsmeral.semnet.crawler.model;
