package xsmeral.pipe.sample;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.logging.Level;
import java.util.logging.Logger;
import xsmeral.pipe.ObjectProcessorException;
import xsmeral.pipe.interfaces.ObjectProcessor;
import xsmeral.pipe.Pipe;

public class Main {

    public static void main(String[] args) {
        int count = args.length > 0 ? Integer.parseInt(args[0]) : 1;
        int time = args.length > 1 ? Integer.parseInt(args[1]) : 5000;
//        int buffSize = args.length > 2 ? Integer.parseInt(args[2]) : 100000;
        //System.out.println(Runtime.getRuntime().availableProcessors() + " processors");
        try {
            ObjectProcessor[] processors = {
                new RandomTripleServer(100000),
                new ParallelTripleMapper(count),
                new GenericCounter(),
                //new TripleMapper(),
                new TripleFileWriter("out_triplez")
            };
            System.out.println("Press a key to start chain");
            new BufferedReader(new InputStreamReader(System.in)).readLine();
            System.err.println("Starting chain");
            Pipe pipe = new Pipe(processors);
            pipe.start(false);
            Thread.sleep(time);
            pipe.stop(false);
        } catch (InterruptedException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ObjectProcessorException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
