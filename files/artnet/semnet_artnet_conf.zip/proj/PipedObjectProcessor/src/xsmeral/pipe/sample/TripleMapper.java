package xsmeral.pipe.sample;

import xsmeral.pipe.LocalObjectFilter;
import xsmeral.pipe.ProcessorStoppedException;
import xsmeral.pipe.interfaces.ObjectProcessorInterface;

/**
 * 
 * @author Ron Šmeral (xsmeral@fi.muni.cz)
 */
@ObjectProcessorInterface(in = Triple.class, out = Triple.class)
public class TripleMapper extends LocalObjectFilter<Triple, Triple> {

    private Triple triple;

    public TripleMapper() {
        super();
    }

    @Override
    public void process() throws ProcessorStoppedException {
        triple = read();
        triple = doMapping(triple);
        write(triple);
    }

    private Triple doMapping(Triple triple) {
        triple.setPredicate(triple.getPredicate().replace("prefix:", "custom:"));
        return triple;
    }
}
