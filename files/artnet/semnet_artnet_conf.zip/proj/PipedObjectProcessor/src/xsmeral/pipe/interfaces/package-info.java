/**
 * Interfaces of processors (source, sink) and annotations
 */
package xsmeral.pipe.interfaces;
