package xsmeral.pipe.sample;

import xsmeral.pipe.LocalObjectFilter;
import xsmeral.pipe.ProcessorStoppedException;
import xsmeral.pipe.interfaces.ObjectProcessorInterface;

@ObjectProcessorInterface(in = Object.class, out = Object.class)
public class GenericCounter extends LocalObjectFilter<Object, Object> {

    private int count = 0;

    public int getCount() {
        return count;
    }

    @Override
    protected void process() throws ProcessorStoppedException {
        Object obj = read();
        write(obj);
        count++;
    }
}
