
Building of domain-specific semantic networks from web pages
============================================================

 -----------------
  1. INTRODUCTION
 -----------------

 This archive contains an implementation of a domain-specific semantic network builder, consisting of a HTML web crawler, Sesame database adapter and various other related classes.

 More information is available on website of the project, http://nlp.fi.muni.cz/projekty/semnet/ .

 
 ------------------------
  2. DIRECTORY STRUCTURE
 ------------------------

  +---doc                           = Documentation (javadoc)
  |   |
  |   +---PipedObjectProcessor
  |   |
  |   +---SemNet
  |
  +---proj                          = NetBeans Projects with sources
  |   |
  |   +---ArtNetScrapers            = Scrapers for ArtNet (CSFD - Film, Actor/Director, 
  |   |                               DBKnih - Author, Book, Short story)
  |   +---CustomTaglets             = Taglets (custom javadoc tags, used in PipedObjectProcessor)
  |   |
  |   +---PipedObjectProcessor      = A processing pipe, the base for SemNet
  |   |
  |   +---SemNet                    = Crawler, scraper, mapper, sesame adapter
  |   
  +---sample                        = Sample semantic network; contains scripts for execution
    |
    +---artnet                      = configuration files of the network
    |
    +---bin                         = The runtime, JARs
    |   |
    |   +--lib                      = Third-party libraries
    |
    +---scrapers                    = JARs of custom scrapers used in ArtNet
    |
    +---serql                       = Sample SeRQL queries
    |
    +---sql                         = SQL queries for schema creation and crawler monitoring


 -------------  
  3. PLATFORM 
 -------------
    
    The implementation is written completely in Java, therefore it should be platform independent. The only dependency is an SQL database with a schema specified in the thesis and on the project website. SQL script for creation of the schema is provided, which is, however, dependent on PostgreSQL.

    The application has been tested and found working on the following configuration:
     
     * Windows 7 64-bit
     * JDK 1.6.0_20
     * PostgreSQL 9.0.3 64-bit
     * Dual-core Intel Pentium processor, 4 GB RAM

    Developed in NetBeans IDE 6.9.1.
	
 ----------
  4. USAGE
 ----------

  There are multiple runnable classes in the implementation. In the directory "sample", executable scripts (Windows, BAT) are provided.
  (With a minor adjustment, they can be run on UNIX systems - the only difference is in path separator character (Semicolon ";" on Windows) and argument passing syntax (The percent sign "%" on windows)).
 
  * run.bat       = runs the crawler, starting where it left off

  * manage.bat    = used for listing/removing managed hosts of the crawler and completely resetting its state

  * query.bat     = a simple query interface, a facade for the Sesame repository querying mechanisms

 -----------
  5. AUTHOR
 -----------

  Ron �meral, xsmeral@fi.muni.cz
 