select pattern, visited, total, visited::real/total::real as ratio from 
	(select pattern, count(*) as visited from artnet.url where visit_count != 0 group by pattern) as visited_table
	natural join 
	(select pattern, count(*) as total from artnet.url group by pattern)  as total_table
	order by ratio, total desc, pattern