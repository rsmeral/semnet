--update artnet.url set last_visited=0 where working=false;
select * from artnet.url where working=false or score != 0;