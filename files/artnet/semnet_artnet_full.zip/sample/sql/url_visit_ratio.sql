select 
	visited, total_urls, visited::real/total_urls::real as ratio
from
	(select
		(select count(*) from artnet.url where visit_count!=0) as visited,
		(select count(*) from artnet.url) as total_urls
	) as url_ratio;
