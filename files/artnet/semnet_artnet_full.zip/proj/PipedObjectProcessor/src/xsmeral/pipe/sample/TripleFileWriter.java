package xsmeral.pipe.sample;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import xsmeral.pipe.LocalObjectSink;
import xsmeral.pipe.ProcessorStoppedException;
import xsmeral.pipe.context.FSContext;
import xsmeral.pipe.interfaces.ObjectProcessorInterface;
import xsmeral.pipe.interfaces.Param;

/**
 * 
 * @author Ron Šmeral (xsmeral@fi.muni.cz)
 */
@ObjectProcessorInterface(in = Triple.class)
public class TripleFileWriter extends LocalObjectSink<Triple> {

    @Param("file")
    private String fileName;
    private PrintWriter pw;
    private Triple triple;
    private int count = 0;

    public TripleFileWriter() {
    }

    public TripleFileWriter(String fileName) {
        this.fileName = fileName;
        initFile();
    }

    private void initFile() {
        try {
            File f = ((FSContext)getContext()).getFile(fileName);
            pw = new PrintWriter(f);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(TripleFileWriter.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void initPostContext() {
        initFile();
    }

    @Override
    public void process() throws ProcessorStoppedException {
        triple = read();
        pw.println(triple);
        count++;
    }

    @Override
    protected void postRun() {
        pw.close();
    }
}
