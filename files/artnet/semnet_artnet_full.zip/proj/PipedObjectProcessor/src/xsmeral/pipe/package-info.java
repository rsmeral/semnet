/**
 * Pipe implementation and exceptions
 */
package xsmeral.pipe;
