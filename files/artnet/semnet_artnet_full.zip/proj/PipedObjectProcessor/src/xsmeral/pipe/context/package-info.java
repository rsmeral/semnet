/**
 * Processing context related classes and annotation types
 */
package xsmeral.pipe.context;
