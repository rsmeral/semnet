package xsmeral.pipe.sample;

import xsmeral.pipe.LocalObjectFilter;
import xsmeral.pipe.ProcessorStoppedException;
import xsmeral.pipe.interfaces.ObjectProcessorInterface;

/**
 *
 * @author Ron Šmeral (xsmeral@fi.muni.cz)
 */
@ObjectProcessorInterface(in = String.class, out = String.class)
public class StringMapper extends LocalObjectFilter<String, String> {

    private String str;

    @Override
    public void process() throws ProcessorStoppedException {
        str = read();
        str = doMapping(str);
        write(str);
    }

    private String doMapping(String str) {
        str.replace("prefix:", "custom:");
        return str;
    }
}
