package xsmeral.pipe.sample;

import java.util.logging.Level;
import java.util.logging.Logger;
import xsmeral.pipe.LocalObjectFilter;
import xsmeral.pipe.ProcessorStoppedException;
import xsmeral.pipe.interfaces.ObjectProcessorInterface;
import xsmeral.pipe.interfaces.Param;

/**
 *
 * @author Ron Šmeral (xsmeral@fi.muni.cz)
 */
@ObjectProcessorInterface(in = Triple.class, out = Triple.class)
public class ParallelTripleMapper extends LocalObjectFilter<Triple, Triple> {

    @Param
    private int threads;
    private Integer count = 0;

    private class InnerMapper implements Runnable {

        private Triple triple;

        public InnerMapper() {
        }

        @Override
        public void run() {
            while (status == Status.RUNNING) {
                try {
                    triple = read();
                    triple = doMapping(triple);
                    write(triple);
                    synchronized (count) {
                        count++;
                    }
                } catch (ProcessorStoppedException ex) {
                    status = Status.STOPPING;
                }
            }
        }

        private Triple doMapping(Triple triple) {
            triple.setPredicate(triple.getPredicate().replace("prefix:", "custom:"));
            double a = 0;
            for (int i = 0; i < 1000; i++) {
                a = Math.log(Math.PI);
            }
            triple.setSubject(triple.getSubject() + Math.round(a));
            return triple;
        }
    }

    public ParallelTripleMapper(int threads) {
        super();
        this.threads = threads;
    }

    public ParallelTripleMapper() {
    }

    @Override
    public void process() {
        Thread[] children = new Thread[threads];
        Thread.currentThread().setName(this.getClass().getSimpleName() + "Manager");
        for (int i = 0; i < threads; i++) {
            children[i] = new Thread(new InnerMapper(), InnerMapper.class.getSimpleName() + i);
            children[i].start();
        }
        try {
            for (Thread t : children) {
                t.join();
            }
            stop();
        } catch (InterruptedException ex) {
            Logger.getLogger(ParallelTripleMapper.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
