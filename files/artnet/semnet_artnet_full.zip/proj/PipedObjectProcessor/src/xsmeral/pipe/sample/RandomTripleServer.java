package xsmeral.pipe.sample;

import xsmeral.pipe.LocalObjectSource;
import xsmeral.pipe.ProcessorStoppedException;
import xsmeral.pipe.interfaces.ObjectProcessorInterface;
import xsmeral.pipe.interfaces.Param;

/**
 * 
 * @author Ron Šmeral (xsmeral@fi.muni.cz>)
 */
@ObjectProcessorInterface(out = Triple.class)
public class RandomTripleServer extends LocalObjectSource<Triple> {

    @Param
    private int count;

    public RandomTripleServer() {
    }

    public RandomTripleServer(int count) {
        this.count = count;
        //br = new BufferedReader(new InputStreamReader(System.in));
    }

    @Override
    public void process() throws ProcessorStoppedException {
        /*System.out.println("Subject:");
        String sub = br.readLine();
        System.out.println("Predicate:");
        String pred = br.readLine();
        System.out.println("Object:");
        String obj = br.readLine();*/
        int i;
        for (i = 0; (i < count) && status == Status.RUNNING; i++) {
            String sub = String.valueOf((char) (Math.random() * 26 + 'a'));
            String pred = String.valueOf((char) (Math.random() * 26 + 'a'));
            String obj = String.valueOf((char) (Math.random() * 26 + 'a'));
            write(new Triple(i + sub, pred, obj));
        }
        //System.out.println("Crawler: After " + i + " triples");
        stop();
        /*while (true) {
        try {
        br.readLine();
        } catch (IOException ex) {
        Logger.getLogger(Crawler.class.getName()).log(Level.SEVERE, null, ex);
        }
        }*/
    }
}
