/**
 * Provides annotations that define relationships between elements of an ontology.
 */
package xsmeral.semnet.scraper.onto;
