/**
 * Core classes of the crawler - the crawler/processor itself, host manager, URL manager, DB layer
 */
package xsmeral.semnet.crawler;