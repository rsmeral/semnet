/**
 * Various utility classes for working with XPath or URLs, and processors for debugging.
 */
package xsmeral.semnet.util;
