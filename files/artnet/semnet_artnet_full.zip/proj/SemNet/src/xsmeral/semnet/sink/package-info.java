/**
 * ObjectSink implementations, specifically Sesame Writer and associated repository factories
 */
package xsmeral.semnet.sink;
