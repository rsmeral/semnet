/**
 * Auxiliary classes used by the crawler providing, for example, robots policy handling and charset detection.
 */
package xsmeral.semnet.crawler.util;
