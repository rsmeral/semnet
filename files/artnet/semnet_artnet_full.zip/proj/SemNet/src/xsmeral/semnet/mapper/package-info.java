/**
 * ObjectFilter implementations used for transforming URIs in statements using a mapping
 */
package xsmeral.semnet.mapper;
